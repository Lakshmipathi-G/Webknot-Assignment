const express = require('express');
const bodyParser = require('body-parser');
const Database = require('better-sqlite3');
const db = new Database('events.db');
const app = express();
app.use(bodyParser.json());

// Create helpers
function run(sql, params=[]) { return db.prepare(sql).run(...params); }
function get(sql, params=[]) { return db.prepare(sql).get(...params); }
function all(sql, params=[]) { return db.prepare(sql).all(...params); }

app.post('/events', (req, res)=>{
  const {id,college_id,title,type,date,capacity} = req.body;
  try{ run('INSERT INTO events(id,college_id,title,type,date,capacity) VALUES (?,?,?,?,?,?)',[id,college_id,title,type,date,capacity]); res.status(201).json({ok:true}); }
  catch(e){ res.status(400).json({error:e.message}); }
});

app.post('/students', (req,res)=>{
  const {id,college_id,name,email} = req.body;
  try{ run('INSERT INTO students(id,college_id,name,email) VALUES (?,?,?,?)',[id,college_id,name,email]); res.status(201).json({ok:true}); }
  catch(e){ res.status(400).json({error:e.message}); }
});

app.post('/register', (req,res)=>{
  const {student_id,event_id} = req.body;
  try{
    // prevent duplicate
    const existing = get('SELECT id FROM registrations WHERE student_id=? AND event_id=?',[student_id,event_id]);
    if(existing) return res.status(409).json({error:'duplicate'});
    run('INSERT INTO registrations(student_id,event_id,registered_at) VALUES (?,?,datetime("now"))',[student_id,event_id]);
    res.status(201).json({ok:true});
  }catch(e){ res.status(400).json({error:e.message}); }
});

app.post('/attendance', (req,res)=>{
  const {registration_id,present} = req.body;
  try{
    run('INSERT INTO attendance(registration_id,present,checked_in_at) VALUES (?,?,datetime("now"))',[registration_id, present?1:0]);
    res.json({ok:true});
  }catch(e){ res.status(400).json({error:e.message}); }
});

app.post('/feedback', (req,res)=>{
  const {registration_id,rating,comment} = req.body;
  try{ run('INSERT INTO feedback(registration_id,rating,comment) VALUES (?,?,?)',[registration_id,rating,comment]); res.json({ok:true}); }
  catch(e){ res.status(400).json({error:e.message}); }
});

// Reports
app.get('/reports/popularity', (req,res)=>{
  const rows = all('SELECT e.id,e.title,COUNT(r.id) as registrations FROM events e LEFT JOIN registrations r ON e.id=r.event_id GROUP BY e.id ORDER BY registrations DESC');
  res.json(rows);
});

app.get('/reports/attendance/:event_id', (req,res)=>{
  const event_id = req.params.event_id;
  const total = get('SELECT COUNT(a.id) as total FROM attendance a JOIN registrations r ON a.registration_id=r.id WHERE r.event_id=?',[event_id]).total || 0;
  const present = get('SELECT COUNT(a.id) as present FROM attendance a JOIN registrations r ON a.registration_id=r.id WHERE r.event_id=? AND a.present=1',[event_id]).present || 0;
  const pct = total? (present/total*100):0;
  res.json({event_id,total,present,attendance_percentage:pct});
});

app.get('/reports/student/:student_id', (req,res)=>{
  const sid = req.params.student_id;
  const rows = all('SELECT e.id,e.title,a.present FROM events e JOIN registrations r ON e.id=r.event_id LEFT JOIN attendance a ON r.id=a.registration_id WHERE r.student_id=?',[sid]);
  res.json(rows);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server listening on',PORT));

// Flexible report: filter by event type
app.get('/reports/type/:type', (req,res)=>{
  const type = req.params.type;
  const rows = all('SELECT e.id,e.title,COUNT(r.id) as registrations FROM events e LEFT JOIN registrations r ON e.id=r.event_id WHERE e.type=? GROUP BY e.id ORDER BY registrations DESC',[type]);
  res.json(rows);
});
