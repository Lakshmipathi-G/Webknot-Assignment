-- SQLite schema for prototype
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  college_id TEXT,
  title TEXT,
  type TEXT,
  date TEXT,
  capacity INTEGER,
  cancelled INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS students (
  id TEXT PRIMARY KEY,
  college_id TEXT,
  name TEXT,
  email TEXT
);
CREATE TABLE IF NOT EXISTS registrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id TEXT,
  event_id TEXT,
  registered_at TEXT,
  UNIQUE(student_id,event_id),
  FOREIGN KEY(student_id) REFERENCES students(id),
  FOREIGN KEY(event_id) REFERENCES events(id)
);
CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  registration_id INTEGER,
  present INTEGER,
  checked_in_at TEXT,
  FOREIGN KEY(registration_id) REFERENCES registrations(id)
);
CREATE TABLE IF NOT EXISTS feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  registration_id INTEGER,
  rating INTEGER,
  comment TEXT,
  FOREIGN KEY(registration_id) REFERENCES registrations(id)
);

-- Seed sample data
INSERT OR IGNORE INTO events(id,college_id,title,type,date,capacity) VALUES ('C1_E1','C1','Intro to AI','Workshop','2025-09-10',100);
INSERT OR IGNORE INTO students(id,college_id,name,email) VALUES ('S1','C1','Vishwa','vishwa@example.com');
INSERT OR IGNORE INTO registrations(student_id,event_id,registered_at) VALUES ('S1','C1_E1',datetime('now'));
