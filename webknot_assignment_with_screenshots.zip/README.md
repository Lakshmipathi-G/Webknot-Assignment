# Webknot - Campus Drive Assignment (Prototype)

This repository contains a minimal prototype for the Campus Event Management reporting task.

## Contents
- server.js - Node.js + Express API server
- db_init.sql - SQLite schema and seed
- queries.sql - Report queries
- design_doc.md - concise design document
- ai_conversation_log.txt - AI chat excerpt
- reports.md - sample report outputs (query results)

## How to run (local)
1. Install Node.js (v16+).
2. In project root: `npm install`
3. Initialize DB: `sqlite3 events.db < db_init.sql`
4. Start server: `node server.js`
5. Use curl/Postman to test endpoints listed in design_doc.md

Note: Customize README before final submission to reflect your personal understanding as required by the assignment.
