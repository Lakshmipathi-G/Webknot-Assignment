-- Report queries
-- 1. Total registrations per event
SELECT e.id,e.title,COUNT(r.id) as registrations FROM events e LEFT JOIN registrations r ON e.id=r.event_id GROUP BY e.id ORDER BY registrations DESC;

-- 2. Attendance percentage for an event (replace 'C1_E1')
SELECT 
  SUM(CASE WHEN a.present=1 THEN 1 ELSE 0 END)*1.0 / COUNT(a.id) * 100.0 AS attendance_percentage
FROM attendance a JOIN registrations r ON a.registration_id=r.id WHERE r.event_id='C1_E1';

-- 3. Average feedback score for event
SELECT e.id,e.title,AVG(f.rating) as avg_rating FROM events e JOIN registrations r ON e.id=r.event_id JOIN feedback f ON r.id=f.registration_id WHERE e.id='C1_E1' GROUP BY e.id;

-- 4. Top 3 most active students (by attendance count)
SELECT r.student_id, s.name, COUNT(a.id) as attended FROM registrations r JOIN attendance a ON r.id=a.registration_id JOIN students s ON s.id=r.student_id WHERE a.present=1 GROUP BY r.student_id ORDER BY attended DESC LIMIT 3;
