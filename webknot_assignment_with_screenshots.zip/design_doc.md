# Design Document - Campus Event Management (Concise)
## Assumptions
- Single DB for all colleges; event IDs unique with prefix collegeId_eventId.
- Feedback optional (1-5). Duplicate registrations prevented by unique(student_id,event_id).
- Scale: 50 colleges * 500 students * 20 events/sem => ~500k rows manageable in SQLite for prototype.

## Data to Track
- events(id, college_id, title, type, date, capacity)
- students(id, college_id, name, email)
- registrations(id, student_id, event_id, registered_at)
- attendance(id, registration_id, present, checked_in_at)
- feedback(id, registration_id, rating, comment)

## DB Schema (table sketches)
See db_init.sql for CREATE TABLE statements.

## APIs (outline)
- POST /events -> create event
- POST /students -> create student
- POST /register -> register student for event
- POST /attendance -> mark attendance
- POST /feedback -> submit feedback
- GET /reports/popularity -> registrations per event
- GET /reports/attendance/:event_id -> attendance percentage
- GET /reports/student/:student_id -> events attended

## Workflows
1. Student browses -> registers -> on event day checks in -> optionally submits feedback -> reports generated from tables.

## Edge Cases
- Duplicate registrations -> return 409.
- Event full -> return 400.
- Cancelled events -> flag event.cancelled, disallow check-ins.
