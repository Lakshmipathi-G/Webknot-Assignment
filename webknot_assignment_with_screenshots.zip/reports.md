# Reports (sample)
Run the queries in queries.sql against events.db (created via db_init.sql) to get:
- Event popularity (sorted by registrations)
- Attendance percentage per event
- Average feedback score per event
- Top 3 most active students

- Flexible report by event type available at `/reports/type/:type`
